'use strict';

var module = angular.module('moviecat.coming_soon', ['ngRoute','moviecat.services.http'])

module.config(['$routeProvider', function($routeProvider) {
	$routeProvider.when('/coming_soon/:page', {
		templateUrl: 'coming_soon/view.html',
		controller: 'ComingSoonController'
	});
}])

module.controller('ComingSoonController', ['$scope','$routeParams','HttpService',function($scope,$routeParams,HttpService) {
	var count = 5;
	var page = parseInt($routeParams.page);
	var start = (page - 1) * count;
	$scope.subjects = [];
	$scope.message = []
	$scope.totalCount = 0;
	HttpService.jsonp("http://api.douban.com/v2/movie/coming_soon",
		{start: start, count: count},
		function(data){
			$scope.subjects = data.subjects;
			$scope.totalCount = data.total;
			$scope.totalPages = Math.ceil($scope.totalCount / count); //得到共有多少页
			$scope.$apply('subjects');
		})
}]);


















